﻿#include "entity.h"
#include "image.h"
#include "camera.h"

// Helper to convert from clip space (-1..1) to screen coordinates
static inline Vector2 ClipToScreen(const Vector3& clipPos, int width, int height) {
    // clipPos assumed already projected (NDC) in range [-1,1]
    float x = (clipPos.x * 0.5f + 0.5f) * (float)width;
    float y = (1.0f - (clipPos.y * 0.5f + 0.5f)) * (float)height; // flip y
    return Vector2(x, y);
}

void Entity::Update(float seconds_elapsed)
{
    // simple animation: rotate and bob up/down and oscillate scale
    angle += rotationSpeed * seconds_elapsed;
    float bob = sin(angle) * 0.5f; // vertical offset
    float s = scale + sin(angle * scaleSpeed) * 0.25f;

    // rebuild model matrix
    Matrix44 t; t.SetIdentity(); t.MakeTranslationMatrix(basePosition.x, basePosition.y + bob, basePosition.z);
    Matrix44 r0; r0.SetIdentity(); r0.MakeRotationMatrix(initialRotationX, Vector3(1,0,0));
    Matrix44 rY; rY.SetIdentity(); rY.MakeRotationMatrix(initialRotationY, Vector3(0,1,0));
    Matrix44 r1; r1.SetIdentity(); r1.MakeRotationMatrix(angle, Vector3(0,1,0));

    Matrix44 r = r0 * rY * r1;

    Matrix44 sc; sc.SetIdentity(); sc.MakeScaleMatrix(s, s, s);

    model = t * r * sc;
}

void Entity::Render(Image* framebuffer, Camera* camera, const Color& color, FloatImage* zbuffer)
{
    if (!mesh || !framebuffer || !camera) return;

    const std::vector<Vector3>& verts = mesh->GetVertices();
    const std::vector<Vector2>& uvs = mesh->GetUVs();

    for (size_t i = 0; i < verts.size(); i += 3)
    {
        // Local
        Vector3 v0 = verts[i];
        Vector3 v1 = verts[i + 1];
        Vector3 v2 = verts[i + 2];

        // Model → World
        v0 = model * v0;
        v1 = model * v1;
        v2 = model * v2;

        // World → NDC (Project)
        v0 = camera->ProjectVector(v0);
        v1 = camera->ProjectVector(v1);
        v2 = camera->ProjectVector(v2);
        
        float near_plane = camera->near_plane;
        float far_plane = camera->far_plane;

        if (
            (v0.z < near_plane && v1.z < near_plane && v2.z < near_plane) ||
            (v0.z > far_plane && v1.z > far_plane && v2.z > far_plane)
            )
        {
            continue;
        }


        // NDC → Screen
        v0.x = (v0.x + 1.0f) * 0.5f * framebuffer->width;
        v0.y = (1.0f - (v0.y + 1.0f) * 0.5f) * framebuffer->height;

        v1.x = (v1.x + 1.0f) * 0.5f * framebuffer->width;
        v1.y = (1.0f - (v1.y + 1.0f) * 0.5f) * framebuffer->height;

        v2.x = (v2.x + 1.0f) * 0.5f * framebuffer->width;
        v2.y = (1.0f - (v2.y + 1.0f) * 0.5f) * framebuffer->height;

        // Build triangle
        sTriangleInfo tri;

        tri.p0 = Vector3(v0.x, v0.y, v0.z);
        tri.p1 = Vector3(v1.x, v1.y, v1.z);
        tri.p2 = Vector3(v2.x, v2.y, v2.z);

        // Vertex colors
        tri.c0 = Color::RED;
        tri.c1 = Color::GREEN;
        tri.c2 = Color::BLUE;

        // UVs
        if (uvs.size() >= i + 3)
        {
            tri.uv0 = uvs[i];
            tri.uv1 = uvs[i + 1];
            tri.uv2 = uvs[i + 2];
        }
        else
        {
            tri.uv0 = tri.uv1 = tri.uv2 = Vector2(0, 0);
        }

        // Texture
        tri.texture = useTexture ? texture : nullptr;

        // No perspective correction (ProjectVector already did divide)
        tri.rw0 = tri.rw1 = tri.rw2 = 1.0f;

        // Draw
        if (useOcclusion)
            framebuffer->DrawTriangleInterpolated(tri, zbuffer);
        else
            framebuffer->DrawTriangleInterpolated(tri, nullptr);
    }
}


