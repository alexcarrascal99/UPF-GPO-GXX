#pragma once
#include "framework.h"
#include "image.h"

class ParticleSystem {
    static const int MAX_PARTICLES = 500;

    struct Particle {
        Vector2 position;
        Vector2 velocity;
        Color color;
        float acceleration;
        float ttl;
        bool inactive;
    };

    Particle particles[MAX_PARTICLES];

public:
    void Init(int screenWidth, int screenHeight);
    void Render(Image* framebuffer);
    void Update(float dt, int screenWidth, int screenHeight);
};

#include <stdlib.h>
#include <cmath>

inline void ParticleSystem::Init(int screenWidth, int screenHeight) {
    if (screenWidth <= 0) screenWidth = 800;
    if (screenHeight <= 0) screenHeight = 600;

    for (int i = 0; i < MAX_PARTICLES; ++i) {
        particles[i].position = Vector2((float)(rand() % screenWidth), (float)(rand() % screenHeight));
        float vx = ((rand() % 200) - 100) / 100.0f;
        float vy = -((rand() % 50 + 20) / 10.0f);
        particles[i].velocity = Vector2(vx, vy);
        particles[i].color = Color::WHITE;
        particles[i].acceleration = 0.0f;
        particles[i].ttl = (float)(rand() % 500) / 100.0f + 1.0f;
        particles[i].inactive = false;
    }
}

inline void ParticleSystem::Update(float dt, int screenWidth, int screenHeight) {
    if (screenWidth <= 0) screenWidth = 800;
    if (screenHeight <= 0) screenHeight = 600;

    const float leftBound = -50.0f;
    const float rightBound = (float)screenWidth + 50.0f;
    const float topRespawn = (float)screenHeight + 50.0f;

    for (int i = 0; i < MAX_PARTICLES; ++i) {
        if (particles[i].inactive) continue;
        particles[i].velocity.y += particles[i].acceleration * dt;
        particles[i].position.x += particles[i].velocity.x * dt * 60.0f;
        particles[i].position.y += particles[i].velocity.y * dt * 60.0f;
        particles[i].ttl -= dt;
        if (particles[i].position.y < 0.0f || particles[i].ttl <= 0.0f || particles[i].position.x < leftBound || particles[i].position.x > rightBound) {
            particles[i].position.y = topRespawn + (float)(rand() % 50);
            particles[i].position.x = (float)(rand() % screenWidth);
            particles[i].velocity.x = ((rand() % 200) - 100) / 100.0f;
            particles[i].velocity.y = -((rand() % 50 + 20) / 10.0f);
            particles[i].ttl = (float)(rand() % 500) / 100.0f + 1.0f;
            particles[i].inactive = false;
        }
    }
}

inline void ParticleSystem::Render(Image* framebuffer) {
    if (!framebuffer) return;
    for (int i = 0; i < MAX_PARTICLES; ++i) {
        if (particles[i].inactive) continue;
        int x = (int)std::round(particles[i].position.x);
        int y = (int)std::round(particles[i].position.y);
        if (x >= 0 && x < (int)framebuffer->width && y >= 0 && y < (int)framebuffer->height) {
            framebuffer->SetPixel(x, y, particles[i].color);
            for (int ox = -1; ox <= 1; ++ox) {
                for (int oy = -1; oy <= 1; ++oy) {
                    int nx = x + ox; int ny = y + oy;
                    if (nx >= 0 && nx < (int)framebuffer->width && ny >= 0 && ny < (int)framebuffer->height)
                        framebuffer->SetPixel(nx, ny, particles[i].color);
                }
            }
        }
    }
}