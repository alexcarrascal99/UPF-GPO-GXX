#pragma once
#include "image.h"
#include "framework.h"
#include <vector>

enum ButtonType
{
	BUTTON_PENCIL,
	BUTTON_COLOR,
	BUTTON_ERASER,
	BUTTON_TRIANGLE,
	BUTTON_LINE,
	BUTTON_RECTANGLE,
	BUTTON_CLEAR,
	BUTTON_LOAD,
	BUTTON_SAVE
};

class Button
{
public:
	Image image;
	Vector2 position;
	ButtonType type;
	Color color;

	Button() {
		type = BUTTON_PENCIL;
		color = Color::WHITE;
	}
	Button(const Image& img, const Vector2& pos, ButtonType t, Color c)
	{
		image = img;
		position = pos;
		type = t;
		color = c;
	}

	//verificamos si el mouse esta dentro del bot�n
	bool IsMouseInside(const Vector2& mousePosition)
	{
		return mousePosition.x >= position.x &&
			mousePosition.x <= position.x + (float)image.width &&
			mousePosition.y >= position.y &&
			mousePosition.y <= position.y + (float)image.height;
	}

	//renderizar el bot�n sobre el framuebuffer	
	void Render(Image& framebuffer)
	{
		framebuffer.DrawImage(image, (int)position.x, (int)position.y);
	}
};

