#pragma once

#include "framework.h"
#include "mesh.h"
#include "image.h"
#include "camera.h"

class Entity {
public:
    Mesh* mesh;
    Matrix44 model; // model matrix

    // Rendering mode
    enum class eRenderMode { POINTCLOUD, WIREFRAME, TRIANGLES, TRIANGLES_INTERPOLATED };
    eRenderMode mode = eRenderMode::TRIANGLES_INTERPOLATED;

    // Use texture or vertex colors
    bool useTexture = false;
    bool useOcclusion = true; // Z-buffer on/off
    bool useInterpolatedUV = true; // when texturing

    Image* texture = nullptr; // per-entity texture

    // Animation parameters
    Vector3 basePosition;
    float angle = 0.0f;
    float rotationSpeed = 1.0f; // rad/sec
    float scale = 1.0f;
    float scaleSpeed = 0.0f;

    bool wireframe = false;

    // Initial orientation offsets
    float initialRotationX = 0.0f; // radians
    float initialRotationY = 0.0f; // radians

    Entity() : mesh(nullptr) { model.SetIdentity(); basePosition = Vector3(0,0,0); }
    ~Entity() { if (mesh) delete mesh; if (texture) delete texture; }

    // Set model matrix helpers
    void SetModel(const Matrix44& m) { model = m; }

    // Animate entity each frame (modifies model)
    void Update(float seconds_elapsed);

    // Render the entity as a wireframe into the framebuffer using the camera
    void Render(Image* framebuffer, Camera* camera, const Color& color, FloatImage* zbuffer);
};
