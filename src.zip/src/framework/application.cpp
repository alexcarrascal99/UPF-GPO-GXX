#include "application.h"
#include "mesh.h"
#include "shader.h"
#include "utils.h" 
#include "button.h"
#include "entity.h"


Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->mouse_state = 0;
	this->time = 0.f;
	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(nullptr);

	this->framebuffer.Resize(w, h);
	this->drawingCanvas.Resize(w, h);
	this->drawingCanvas.Fill(Color::BLACK);
	// Start in animation mode by default (painting UI not used)
	this->animationMode = true;
	this->fillMode = false;
}

Application::~Application()
{
	// delete any created entities
	for (Entity* e : entities) {
		if (e) delete e;
	}
	entities.clear();
}

void Application::Init(void)
{
	std::cout << "Initiating app..." << std::endl;
	Image pencilImg, eraserImg, triangleImg, lineImg, rectImg, clearImg, loadImg, saveImg;
	Image blackImg, blueImg, cyanImg, greenImg, pinkImg, redImg, whiteImg, yellowImg, circleImg, fruitsImg;

	//imagenes de herramientas que se pueden usar
	pencilImg.LoadPNG("images/pencil.png");
	eraserImg.LoadPNG("images/eraser.png");
	triangleImg.LoadPNG("images/triangle.png");
	lineImg.LoadPNG("images/line.png");
	rectImg.LoadPNG("images/rectangle.png");
	clearImg.LoadPNG("images / clear.png");
	loadImg.LoadPNG("images/load.png");
	saveImg.LoadPNG("images/save.png");

	//colores disponibles
	blackImg.LoadPNG("images/black.png");
	blueImg.LoadPNG("images/blue.png");
	cyanImg.LoadPNG("images/cyan.png");
	greenImg.LoadPNG("images/green.png");
	pinkImg.LoadPNG("images/pink.png");
	redImg.LoadPNG("images/red.png");
	whiteImg.LoadPNG("images/white.png");
	yellowImg.LoadPNG("images/yellow.png");

	float x = 10.f;
	float y = (float)window_height - 50.f;//barra inferior

	buttons.push_back(Button(pencilImg, Vector2(x, y), BUTTON_PENCIL, Color::WHITE)); x += 50.f;
	
	//el rosa se llama rosa pero no lo detecta asi que hemos peusto purple
	buttons.push_back(Button(blackImg, Vector2(x, y), BUTTON_COLOR, Color::BLACK)); x += 50.f;
	buttons.push_back(Button(blueImg, Vector2(x, y), BUTTON_COLOR, Color::BLUE)); x += 50.f;
	buttons.push_back(Button(cyanImg, Vector2(x, y), BUTTON_COLOR, Color::CYAN)); x += 50.f;
	buttons.push_back(Button(greenImg, Vector2(x, y), BUTTON_COLOR, Color::GREEN)); x += 50.f;
	buttons.push_back(Button(pinkImg, Vector2(x, y), BUTTON_COLOR, Color::PURPLE)); x += 50.f;
	buttons.push_back(Button(redImg, Vector2(x, y), BUTTON_COLOR, Color::RED)); x += 50.f;
	buttons.push_back(Button(whiteImg, Vector2(x, y), BUTTON_COLOR, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(yellowImg, Vector2(x, y), BUTTON_COLOR, Color::YELLOW)); x += 50.f;

	buttons.push_back(Button(eraserImg, Vector2(x, y), BUTTON_ERASER, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(triangleImg, Vector2(x, y), BUTTON_TRIANGLE, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(lineImg, Vector2(x, y), BUTTON_LINE, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(rectImg, Vector2(x, y), BUTTON_RECTANGLE, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(clearImg, Vector2(x, y), BUTTON_CLEAR, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(loadImg, Vector2(x, y), BUTTON_LOAD, Color::WHITE)); x += 50.f;
	buttons.push_back(Button(saveImg, Vector2(x, y), BUTTON_SAVE, Color::WHITE));

	// myParticles.Init(window_width, window_height); // particles removed

	// Setup camera to view the scene (moved closer by default)
	camera.SetPerspective(60.0f, window_width / (float)window_height, 0.1f, 1.2f);
	camera.LookAt(Vector3(0.0f, 0.0f, 3.0f), Vector3(0.0f, 0.0f, 0.0f), Vector3(0.0f, 1.0f, 0.0f));
	camera.UpdateViewMatrix();
	camera.UpdateProjectionMatrix();

	// Create multiple animated entities (at least 3)
	{
		Entity* e1 = new Entity();
		e1->mesh = new Mesh();
		if (e1->mesh->LoadOBJ("meshes/lee.obj")) {
			// center and disable auto-rotation
			e1->basePosition = Vector3(0.0f, 0.0f, 0.0f);
			e1->rotationSpeed = 0.0f; // stop automatic spinning
			e1->scale = 0.95f;
			e1->scaleSpeed = 0.0f;
			// orient: flip X so head is upright
			e1->initialRotationX = PI; // flip 180 deg around X to correct head orientation
			// compute yaw so model faces camera center
			{
				Vector3 dir = camera.center - e1->basePosition;
				float yaw = atan2f(dir.x, dir.z) + PI; // rotate to face camera
				e1->initialRotationY = yaw;
			}
			// load texture for this entity (do not flip Y here)
			e1->texture = new Image();
			if (!e1->texture->LoadTGA("textures/lee_color_specular.tga", true)) {
				delete e1->texture;
				e1->texture = nullptr;
			} 
			entities.push_back(e1);
		} else { delete e1; }

		Entity* e2 = new Entity();
		e2->mesh = new Mesh();
		if (e2->mesh->LoadOBJ("meshes/lee.obj")) {
			// place close to the right so it does not overlap too much
			e2->basePosition = Vector3(0.8f, 0.0f, 0.0f);
			e2->rotationSpeed = 0.0f;
			e2->scale = 0.95f;
			e2->scaleSpeed = 0.0f;
			e2->initialRotationX = PI;
			// compute yaw so model faces camera center
			{
				Vector3 dir = camera.center - e2->basePosition;
				float yaw = atan2f(dir.x, dir.z) + PI;
				e2->initialRotationY = yaw;
			}
			// load texture without flipping Y
			e2->texture = new Image();
			if (!e2->texture->LoadTGA("textures/lee_color_specular.tga", true)) {
				delete e2->texture;
				e2->texture = nullptr;
			}
			entities.push_back(e2);
		} else { delete e2; }

		Entity* e3 = new Entity();
		e3->mesh = new Mesh();
		if (e3->mesh->LoadOBJ("meshes/lee.obj")) {
			// place close to the left so it does not overlap too much
			e3->basePosition = Vector3(-0.8f, 0.0f, 0.0f);
			e3->rotationSpeed = 0.0f;
			e3->scale = 0.95f;
			e3->scaleSpeed = 0.0f;
			e3->initialRotationX = PI;
			// compute yaw so model faces camera center
			{
				Vector3 dir = camera.center - e3->basePosition;
				float yaw = atan2f(dir.x, dir.z) + PI;
				e3->initialRotationY = yaw;
			}
			// load texture without flipping Y
			e3->texture = new Image();
			if (!e3->texture->LoadTGA("textures/lee_color_specular.tga", true)) {
				delete e3->texture;
				e3->texture = nullptr;
			}
			entities.push_back(e3);
		} else { delete e3; }
	}

	// Show single central entity by default so it's visible and close
	singleEntityMode = true;

	// previously there was a single example entity; it's now stored in entities
}


void Application::Render(void)
{
	framebuffer.Fill(Color::BLACK);//limpiamos la pantalla de lo que haya antes

	// Painting UI not used in animation mode anymore: skip drawing the drawing canvas and buttons
	// (framebuffer is cleared above)

	// Create Z-buffer for this frame
	FloatImage zbuffer(framebuffer.width, framebuffer.height);
	zbuffer.Fill(1e30f); // large far depth

	// Render entities using Z-buffer when in animation mode
	if (animationMode) {
		if (singleEntityMode) {
			if (!entities.empty()) {
				Entity* e = entities[0];
				if (e) {
					// render single entity in white for clarity
					e->Render(&framebuffer, &camera, Color::WHITE, &zbuffer);
				}
			}
		} else {
			for (size_t i = 0; i < entities.size(); ++i) {
				Entity* e = entities[i];
				if (e) {
					Color col = (i % 2 == 0) ? Color::BLUE : Color::RED;
					e->Render(&framebuffer, &camera, col, &zbuffer);
				}
			}
		}
	}

	framebuffer.Render();
}

// Called after render
void Application::Update(float seconds_elapsed)
{
	if (animationMode) {
		// myParticles.Update(seconds_elapsed, window_width, window_height); // particles removed
		for (Entity* e : entities) {
			if (e) e->Update(seconds_elapsed);
		}
	}
}

//keyboard press event 
void Application::OnKeyPressed( SDL_KeyboardEvent event )
{
	switch(event.keysym.sym) {
		case SDLK_ESCAPE: exit(0); break; // ESC key, kill the app

		// Mode keys: draw single or multiple entities
		case SDLK_1:
			singleEntityMode = true;
			animationMode = true;
			std::cout << "Mode: Single Entity" << std::endl;
			break;

		case SDLK_2:
			singleEntityMode = false;
			animationMode = true;
			std::cout << "Mode: Multiple Entities" << std::endl;
			break;

		// Select camera property to modify
		case SDLK_n: // Select NEAR
			currentProperty = CurrentProperty::PROP_CAMERA_NEAR;
			std::cout << "Property: NEAR" << std::endl;
			break;

		case SDLK_f: // Select FAR
			currentProperty = CurrentProperty::PROP_CAMERA_FAR;
			std::cout << "Property: FAR" << std::endl;
			break;

		case SDLK_v: // Select FOV
			currentProperty = CurrentProperty::PROP_CAMERA_FOV;
			std::cout << "Property: FOV" << std::endl;
			break;
        // Toggle useTexture across all entities

		case SDLK_w: // Wireframe toggle
		{
			for (Entity* e : entities)
				if (e) e->wireframe = !e->wireframe;

			std::cout << "Wireframe toggled" << std::endl;
		}
		break;

		case SDLK_t:
		{
			for (Entity* e : entities) if (e) e->useTexture = !e->useTexture;
			std::cout << "Toggled useTexture for all entities. Now = " << (entities.empty() ? 0 : entities[0]->useTexture) << std::endl;
		}
		break;

		// Toggle occlusion (Z-buffer) across all entities
		case SDLK_z:
		{
			for (Entity* e : entities) if (e) e->useOcclusion = !e->useOcclusion;
			std::cout << "Toggled useOcclusion for all entities. Now = " << (entities.empty() ? 0 : entities[0]->useOcclusion) << std::endl;
		}
		break;

		// Toggle UV interpolation vs plain color
		case SDLK_c:
		{
			for (Entity* e : entities) if (e) e->useInterpolatedUV = !e->useInterpolatedUV;
			std::cout << "Toggled useInterpolatedUV for all entities. Now = " << (entities.empty() ? 0 : entities[0]->useInterpolatedUV) << std::endl;
		}
		break;

		// Increase / decrease current property
		case SDLK_PLUS:
		case SDLK_KP_PLUS:

			if (currentProperty == CurrentProperty::PROP_CAMERA_FOV)
			{
				camera.fov += 1.0f;
				if (camera.fov > 179.0f) camera.fov = 179.0f;
			}
			else if (currentProperty == CurrentProperty::PROP_CAMERA_NEAR)
			{
				camera.near_plane += 0.05f;
				if (camera.near_plane > camera.far_plane - 0.1f)
					camera.near_plane = camera.far_plane - 0.1f;
			}
			else if (currentProperty == CurrentProperty::PROP_CAMERA_FAR)
			{
				camera.far_plane += 1.0f;
			}

			camera.SetPerspective(
				camera.fov,
				window_width / (float)window_height,
				camera.near_plane,
				camera.far_plane
			);

			break;

		case SDLK_MINUS:
		case SDLK_KP_MINUS:

			if (currentProperty == CurrentProperty::PROP_CAMERA_FOV)
			{
				camera.fov -= 1.0f;
				if (camera.fov < 1.0f) camera.fov = 1.0f;
			}
			else if (currentProperty == CurrentProperty::PROP_CAMERA_NEAR)
			{
				camera.near_plane -= 0.05f;
				if (camera.near_plane < 0.01f)
					camera.near_plane = 0.01f;
			}
			else if (currentProperty == CurrentProperty::PROP_CAMERA_FAR)
			{
				camera.far_plane -= 1.0f;
				if (camera.far_plane < camera.near_plane + 0.1f)
					camera.far_plane = camera.near_plane + 0.1f;
			}

			camera.SetPerspective(
				camera.fov,
				window_width / (float)window_height,
				camera.near_plane,
				camera.far_plane
			);

			break;

		default:
			break;
	}
}

void Application::OnMouseButtonDown(SDL_MouseButtonEvent event) {
	if (event.button == SDL_BUTTON_LEFT) {
		Vector2 mousePos((float)event.x, (float)(window_height - event.y));

		// Check UI buttons first
		for (auto& b : buttons) {
			if (b.IsMouseInside(mousePos)) {
				selectedTool = b.type;
				if (b.type == BUTTON_COLOR) selectedColor = b.color;

				if (b.type == BUTTON_CLEAR) drawingCanvas.Fill(Color::BLACK);
				if (b.type == BUTTON_SAVE) drawingCanvas.SaveTGA("my_drawing.tga");
				if (b.type == BUTTON_LOAD) drawingCanvas.LoadTGA("my_drawing.tga");
				return;
			}
		}

		if (animationMode) {
			// start orbiting the camera
			cameraOrbiting = true;
			last_mouse_x = event.x;
			last_mouse_y = event.y;
			return;
		}

		// painting mode
		isDrawing = true;
		startPos = mousePos;
	}
	else if (event.button == SDL_BUTTON_RIGHT) {
		// right button used for panning the camera when in animation mode
		if (animationMode) {
			cameraPanning = true;
			last_mouse_x = event.x;
			last_mouse_y = event.y;
			return;
		}
	}
}


void Application::OnMouseButtonUp(SDL_MouseButtonEvent event) {
	if (animationMode) {
		// stop any camera interaction
		if (event.button == SDL_BUTTON_LEFT) cameraOrbiting = false;
		if (event.button == SDL_BUTTON_RIGHT) cameraPanning = false;
	}

	if (event.button == SDL_BUTTON_LEFT && isDrawing) {
		Vector2 mousePos((float)event.x, (float)(window_height - event.y));

		if (selectedTool == BUTTON_LINE) {
			drawingCanvas.DrawLineDDA(startPos.x, startPos.y, mousePos.x, mousePos.y, selectedColor);
		}
		else if (selectedTool == BUTTON_RECTANGLE) {
			int x_origin = (int)fmin(startPos.x, mousePos.x);
			int y_origin = (int)fmin(startPos.y, mousePos.y);

			int width = (int)fabs(mousePos.x - startPos.x);
			int height = (int)fabs(mousePos.y - startPos.y);

			if (width > 0 && height > 0) {
				drawingCanvas.DrawRect(x_origin, y_origin, width, height,
					selectedColor, rectBorderWidth, fillMode, selectedColor);
			}
		}
		else if (selectedTool == BUTTON_TRIANGLE) {
			Vector2 p2 = Vector2(startPos.x, mousePos.y);
			drawingCanvas.DrawTriangle(startPos, mousePos, p2, selectedColor, fillMode, selectedColor);
		}
		isDrawing = false;
	}
}

void Application::OnMouseMove(SDL_MouseButtonEvent event)
{
	Vector2 currentMousePos((float)event.x, (float)(window_height - event.y));

	// Camera orbiting or panning when in animation mode
	if (animationMode) {
		int dx = event.x - last_mouse_x;
		int dy = event.y - last_mouse_y;

		if (cameraOrbiting) {
			// Orbit: rotate eye around center
			float yaw = -dx * 0.005f; // horizontal movement rotates around world up
			float pitch = -dy * 0.005f; // vertical movement rotates around camera right

			Vector3 dir = camera.eye - camera.center; // vector from center to eye
			// rotate around world up (Y)
			Matrix44 Ry; Ry.SetIdentity(); Ry.MakeRotationMatrix(yaw, Vector3(0,1,0));
			dir = Ry * dir;

			// compute camera right axis
			Vector3 forward = (camera.center - camera.eye);
			forward.Normalize();
			Vector3 right = forward.Cross(camera.up);
			right.Normalize();

			Matrix44 Rp; Rp.SetIdentity(); Rp.MakeRotationMatrix(pitch, right);
			dir = Rp * dir;

			camera.eye = camera.center + dir;
			camera.UpdateViewMatrix();
		}

		if (cameraPanning) {
			// Pan: move both eye and center along camera right/up
			float factor = 0.005f * (camera.eye.Distance(camera.center));
			Vector3 forward = (camera.center - camera.eye); forward.Normalize();
			Vector3 right = forward.Cross(camera.up); right.Normalize();
			Vector3 up = camera.up; up.Normalize();

			Vector3 delta = (right * (-(float)dx * factor)) + (up * (-(float)dy * factor));
			camera.eye = camera.eye + delta;
			camera.center = camera.center + delta;
			camera.UpdateViewMatrix();
		}

		last_mouse_x = event.x;
		last_mouse_y = event.y;
		// update stored mouse pos for other systems
		mouse_position = currentMousePos;
		return;
	}

	// Painting behavior if not in animation mode
	if (isDrawing && (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(SDL_BUTTON_LEFT)))
	{
		if (selectedTool == BUTTON_PENCIL)
		{
			drawingCanvas.DrawLineDDA((int)mouse_position.x, (int)mouse_position.y,
				(int)currentMousePos.x, (int)currentMousePos.y, selectedColor);
		}
		else if (selectedTool == BUTTON_ERASER)
		{
			drawingCanvas.DrawRect((int)currentMousePos.x - 5, (int)currentMousePos.y - 5,
				10, 10, Color::BLACK, 1, true, Color::BLACK);
		}
	}

	mouse_position = currentMousePos;
}

void Application::OnWheel(SDL_MouseWheelEvent event)
{
	if (animationMode) {
		float dy = event.preciseY;
		// Adjust field of view for a clearer zoom effect
		float fovStep = 3.0f; // degrees per wheel tick
		camera.fov -= dy * fovStep; // wheel up (positive) -> smaller fov -> zoom in
		if (camera.fov < 1.0f) camera.fov = 1.0f;
		if (camera.fov > 179.0f) camera.fov = 179.0f;
		camera.UpdateProjectionMatrix();

		// Also move eye slightly toward/away from center scaled by current distance
		Vector3 forward = (camera.center - camera.eye);
		float dist = forward.Length();
		if (dist > 0.0001f) {
			forward.Normalize();
			float zoomFactor = 0.15f * dist; // scale movement to distance for noticeable effect
			camera.eye = camera.eye + forward * (dy * zoomFactor);
			// prevent camera crossing center
			Vector3 newDir = camera.center - camera.eye;
			if (newDir.Length() < 0.1f) {
				camera.eye = camera.center - forward * 0.1f;
			}
		}
		camera.UpdateViewMatrix();
		std::cout << "camera.fov=" << camera.fov << " eyeDist=" << (camera.center - camera.eye).Length() << std::endl;
	}
}

void Application::OnFileChanged(const char* filename)
{ 
	Shader::ReloadSingleShader(filename);
}