#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "GL/glew.h"
#include "../extra/picopng.h"
#include "image.h"
#include "utils.h"
#include "camera.h"
#include "mesh.h"

Image::Image() {
	width = 0; height = 0;
	pixels = NULL;
}

Image::Image(unsigned int width, unsigned int height)
{
	this->width = width;
	this->height = height;
	pixels = new Color[width*height];
	memset(pixels, 0, width * height * sizeof(Color));
}

Image::Image(const Image& c)
{
	pixels = NULL;
	width = c.width;
	height = c.height;
	bytes_per_pixel = c.bytes_per_pixel;
	if(c.pixels)
	{
		pixels = new Color[width*height];
		memcpy(pixels, c.pixels, width*height*bytes_per_pixel);
	}
}

Image& Image::operator = (const Image& c)
{
	if(pixels) delete[] pixels;
	pixels = NULL;

	width = c.width;
	height = c.height;
	bytes_per_pixel = c.bytes_per_pixel;

	if(c.pixels)
	{
		pixels = new Color[width*height*bytes_per_pixel];
		memcpy(pixels, c.pixels, width*height*bytes_per_pixel);
	}
	return *this;
}

Image::~Image()
{
	if(pixels) 
		delete[] pixels;
}

void Image::Render()
{
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glDrawPixels(width, height, bytes_per_pixel == 3 ? GL_RGB : GL_RGBA, GL_UNSIGNED_BYTE, pixels);
}

void Image::Resize(unsigned int width, unsigned int height)
{
	Color* new_pixels = new Color[width*height];
	unsigned int min_width = this->width > width ? width : this->width;
	unsigned int min_height = this->height > height ? height : this->height;

	for(unsigned int x = 0; x < min_width; ++x)
		for(unsigned int y = 0; y < min_height; ++y)
			new_pixels[ y * width + x ] = GetPixel(x,y);

	delete[] pixels;
	this->width = width;
	this->height = height;
	pixels = new_pixels;
}

void Image::Scale(unsigned int width, unsigned int height)
{
	Color* new_pixels = new Color[width*height];

	for(unsigned int x = 0; x < width; ++x)
		for(unsigned int y = 0; y < height; ++y)
			new_pixels[ y * width + x ] = GetPixel((unsigned int)(this->width * (x / (float)width)), (unsigned int)(this->height * (y / (float)height)) );

	delete[] pixels;
	this->width = width;
	this->height = height;
	pixels = new_pixels;
}

Image Image::GetArea(unsigned int start_x, unsigned int start_y, unsigned int width, unsigned int height)
{
	Image result(width, height);
	for(unsigned int x = 0; x < width; ++x)
		for(unsigned int y = 0; y < height; ++y)
		{
			if( (x + start_x) < this->width && (y + start_y) < this->height) 
				result.SetPixelUnsafe( x, y, GetPixel(x + start_x,y + start_y) );
		}
	return result;
}

void Image::FlipY()
{
	int row_size = bytes_per_pixel * width;
	Uint8* temp_row = new Uint8[row_size];
#pragma omp simd
	for (int y = 0; y < height * 0.5; y += 1)
	{
		Uint8* pos = (Uint8*)pixels + y * row_size;
		memcpy(temp_row, pos, row_size);
		Uint8* pos2 = (Uint8*)pixels + (height - y - 1) * row_size;
		memcpy(pos, pos2, row_size);
		memcpy(pos2, temp_row, row_size);
	}
	delete[] temp_row;
}

bool Image::LoadPNG(const char* filename, bool flip_y)
{
	std::string sfullPath = absResPath(filename);
	std::ifstream file(sfullPath, std::ios::in | std::ios::binary | std::ios::ate);

	std::streamsize size = 0;
	if (file.seekg(0, std::ios::end).good()) size = file.tellg();
	if (file.seekg(0, std::ios::beg).good()) size -= file.tellg();

	if (!size){
		std::cerr << "--- Failed to load file: " << sfullPath.c_str() << std::endl;
		return false;
	}

	std::vector<unsigned char> buffer;

	if (size > 0)
	{
		buffer.resize((size_t)size);
		file.read((char*)(&buffer[0]), size);
	}
	else
		buffer.clear();

	std::vector<unsigned char> out_image;

	if (decodePNG(out_image, width, height, buffer.empty() ? 0 : &buffer[0], (unsigned long)buffer.size(), true) != 0){
		std::cerr << "--- Failed to load file: " << sfullPath.c_str() << std::endl;
		return false;
	}

	size_t bufferSize = out_image.size();
	unsigned int originalBytesPerPixel = (unsigned int)bufferSize / (width * height);

	bytes_per_pixel = 3;

	if (originalBytesPerPixel == 3) {
		if (pixels) delete[] pixels;
		pixels = new Color[bufferSize];
		memcpy(pixels, &out_image[0], bufferSize);
	}
	else if (originalBytesPerPixel == 4) {
		if (pixels) delete[] pixels;

		unsigned int newBufferSize = width * height * bytes_per_pixel;
		pixels = new Color[newBufferSize];

		unsigned int k = 0;
		for (unsigned int i = 0; i < bufferSize; i += originalBytesPerPixel) {
			pixels[k] = Color(out_image[i], out_image[i + 1], out_image[i + 2]);
			k++;
		}
	}

	if (flip_y)
		FlipY();

	std::cout << "+++ File loaded: " << sfullPath.c_str() << std::endl;

	return true;
}

bool Image::LoadTGA(const char* filename, bool flip_y)
{
	unsigned char TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned char TGAcompare[12];
	unsigned char header[6];
	unsigned int imageSize;
	unsigned int bytesPerPixel;

    std::string sfullPath = absResPath( filename );

	FILE * file = fopen( sfullPath.c_str(), "rb");
   	if ( file == NULL || fread(TGAcompare, 1, sizeof(TGAcompare), file) != sizeof(TGAcompare) ||
		memcmp(TGAheader, TGAcompare, sizeof(TGAheader)) != 0 ||
		fread(header, 1, sizeof(header), file) != sizeof(header))
	{
		std::cerr << "--- File not found: " << sfullPath.c_str() << std::endl;
		if (file == NULL)
			return NULL;
		else
		{
			fclose(file);
			return NULL;
		}
	}

	TGAInfo* tgainfo = new TGAInfo;
    
	tgainfo->width = header[1] * 256 + header[0];
	tgainfo->height = header[3] * 256 + header[2];
    
	if (tgainfo->width <= 0 || tgainfo->height <= 0 || (header[4] != 24 && header[4] != 32))
	{
		std::cerr << "--- Failed to load file: " << sfullPath.c_str() << std::endl;
		fclose(file);
		delete tgainfo;
		return NULL;
	}
    
	tgainfo->bpp = header[4];
	bytesPerPixel = tgainfo->bpp / 8;
	imageSize = tgainfo->width * tgainfo->height * bytesPerPixel;
    
	tgainfo->data = new unsigned char[imageSize];
    
	if (tgainfo->data == NULL || fread(tgainfo->data, 1, imageSize, file) != imageSize)
	{
		std::cerr << "--- Failed to load file: " << sfullPath.c_str() << std::endl;

		if (tgainfo->data != NULL)
			delete[] tgainfo->data;
            
		fclose(file);
		delete tgainfo;
		return false;
	}

	fclose(file);

	if(pixels)
		delete[] pixels;

	width = tgainfo->width;
	height = tgainfo->height;
	pixels = new Color[width*height];

	const char imageDescriptor = header[5];
	bool tgaFlipY = (imageDescriptor & 0x20) > 0;
	bool tgaFlipX = (imageDescriptor & 0x10) > 0;

	if (flip_y) {
		tgaFlipY = !tgaFlipY;
	}

	for (unsigned int y = 0; y < height; ++y) {
		for (unsigned int x = 0; x < width; ++x) {
			unsigned int offsetY = (tgaFlipY ? (height - 1 - y) : y) * width * bytesPerPixel;
			unsigned int offsetX = (tgaFlipX ? (width - 1 - x) : x) * bytesPerPixel;
			unsigned int pos = offsetY + offsetX;
			if( pos + 2 < imageSize )
				SetPixelUnsafe(x, y, Color(tgainfo->data[pos + 2], tgainfo->data[pos + 1], tgainfo->data[pos]));
		}
	}

	delete[] tgainfo->data;
	delete tgainfo;

	std::cout << "+++ File loaded: " << sfullPath.c_str() << std::endl;

	return true;
}

bool Image::SaveTGA(const char* filename)
{
	unsigned char TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	std::string fullPath = absResPath(filename);
	FILE *file = fopen(fullPath.c_str(), "wb");
	if ( file == NULL )
	{
		std::cerr << "--- Failed to save file: " << fullPath.c_str() << std::endl;
		return false;
	}

	unsigned short header_short[3];
	header_short[0] = width;
	header_short[1] = height;
	unsigned char* header = (unsigned char*)header_short;
	header[4] = 24;
	header[5] = 0;

	fwrite(TGAheader, 1, sizeof(TGAheader), file);
	fwrite(header, 1, 6, file);

	unsigned char* bytes = new unsigned char[width*height*3];
	for(unsigned int y = 0; y < height; ++y)
		for(unsigned int x = 0; x < width; ++x)
		{
			Color c = pixels[y*width+x];
			unsigned int pos = (y*width+x)*3;
			bytes[pos+2] = c.r;
			bytes[pos+1] = c.g;
			bytes[pos] = c.b;
		}

	fwrite(bytes, 1, width*height*3, file);
	fclose(file);

	delete[] bytes;

	std::cout << "+++ File saved: " << fullPath.c_str() << std::endl;

	return true;
}

#ifndef IGNORE_LAMBDAS

template <typename F>
void ForEachPixel(Image& img, const Image& img2, F f) {
	for(unsigned int pos = 0; pos < img.width * img.height; ++pos)
		img.pixels[pos] = f( img.pixels[pos], img2.pixels[pos] );
}

#endif

FloatImage::FloatImage(unsigned int width, unsigned int height)
{
	this->width = width;
	this->height = height;
	pixels = new float[width * height];
	memset(pixels, 0, width * height * sizeof(float));
}

FloatImage::FloatImage(const FloatImage& c) {
	pixels = NULL;

	width = c.width;
	height = c.height;
	if (c.pixels)
	{
		pixels = new float[width * height];
		memcpy(pixels, c.pixels, width * height * sizeof(float));
	}
}

FloatImage& FloatImage::operator = (const FloatImage& c)
{
	if (pixels) delete[] pixels;
	pixels = NULL;

	width = c.width;
	height = c.height;
	if (c.pixels)
	{
		pixels = new float[width * height * sizeof(float)];
		memcpy(pixels, c.pixels, width * height * sizeof(float));
	}
	return *this;
}

FloatImage::~FloatImage()
{
	if (pixels)
		delete[] pixels;
}

void FloatImage::Resize(unsigned int width, unsigned int height)
{
	float* new_pixels = new float[width * height];
	unsigned int min_width = this->width > width ? width : this->width;
	unsigned int min_height = this->height > height ? height : this->height;

	for (unsigned int x = 0; x < min_width; ++x)
		for (unsigned int y = 0; y < min_height; ++y)
			new_pixels[y * width + x] = GetPixel(x, y);

	delete[] pixels;
	this->width = width;
	this->height = height;
	pixels = new_pixels;
}

void Image::DrawLineDDA(int x0, int y0, int x1, int y1, const Color& c)
{
	int dx = x1 - x0;
	int dy = y1 - y0;

	int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

	if (steps == 0)
	{
		SetPixel(x0, y0, c);
		return;
	}

	float xIncrement = dx / (float)steps;
	float yIncrement = dy / (float)steps;

	float x = (float)x0;
	float y = (float)y0;

	for (int i = 0; i <= steps; i++)
	{
		SetPixel((int)(x + 0.5f), (int)(y + 0.5f), c);
		x += xIncrement;
		y += yIncrement;
	}
}

void Image::DrawRect(int x, int y, int w, int h,
	const Color& borderColor,
	int borderWidth,
	bool isFilled,
	const Color& fillColor)
{
	//seguridad
	if (w <= 0 || h <= 0 || borderWidth < 0)
		return;

	//relleno
	if (isFilled)
	{
		for (int i = x + borderWidth; i < x + w - borderWidth; ++i)
		{
			for (int j = y + borderWidth; j < y + h - borderWidth; ++j)
			{
				SetPixel(i, j, fillColor);
			}
		}
	}

	//bordes
	for (int bw = 0; bw < borderWidth; ++bw)
	{
		//horizontal superior e inferior
		for (int i = x + bw; i < x + w - bw; ++i)
		{
			SetPixel(i, y + bw, borderColor);
			SetPixel(i, y + h - 1 - bw, borderColor);
		}

		//vertical izquierda y derecha
		for (int j = y + bw; j < y + h - bw; ++j)
		{
			SetPixel(x + bw, j, borderColor);
			SetPixel(x + w - 1 - bw, j, borderColor);
		}
	}
}

void Image::ScanLineDDA(int y, float x0, float x1, const Color& c)
{
	if (x0 > x1)
		std::swap(x0, x1);

	float dx = x1 - x0;
	int steps = (int)dx;

	if (steps <= 0)
		return;

	float x = x0;
	float xIncrement = dx / (float)steps;

	for (int i = 0; i <= steps; ++i)
	{
		SetPixel((int)(x + 0.5f), y, c);
		x += xIncrement;
	}
}

void Image::DrawTriangle(
	const Vector2& p0,
	const Vector2& p1,
	const Vector2& p2,
	const Color& borderColor,
	bool isFilled,
	const Color& fillColor)
{
	//dibujamos primero los bordes
	DrawLineDDA((int)p0.x, (int)p0.y, (int)p1.x, (int)p1.y, borderColor);
	DrawLineDDA((int)p1.x, (int)p1.y, (int)p2.x, (int)p2.y, borderColor);
	DrawLineDDA((int)p2.x, (int)p2.y, (int)p0.x, (int)p0.y, borderColor);

	if (!isFilled)
		return;
	Vector2 v0 = p0;
	Vector2 v1 = p1;
	Vector2 v2 = p2;

	//ordenamos
	if (v1.y < v0.y) std::swap(v0, v1);
	if (v2.y < v0.y) std::swap(v0, v2);
	if (v2.y < v1.y) std::swap(v1, v2);

	//calculamos pendientes
	float dx01 = (v1.y - v0.y) != 0 ? (v1.x - v0.x) / (v1.y - v0.y) : 0;
	float dx02 = (v2.y - v0.y) != 0 ? (v2.x - v0.x) / (v2.y - v0.y) : 0;
	float dx12 = (v2.y - v1.y) != 0 ? (v2.x - v1.x) / (v2.y - v1.y) : 0;

	float sx = v0.x;
	float ex = v0.x;

	//parte superior del tri�ngulo
	for (int y = (int)v0.y; y < (int)v1.y; ++y)
	{
		ScanLineDDA(y, sx, ex, fillColor);
		sx += dx01;
		ex += dx02;
	}

	//parte inferior del tri�ngulo
	sx = v1.x;
	for (int y = (int)v1.y; y <= (int)v2.y; ++y)
	{
		ScanLineDDA(y, sx, ex, fillColor);
		sx += dx12;
		ex += dx02;
	}
}
void Image::DrawImage(const Image& image, int x, int y)
{
	for (unsigned int ix = 0; ix < image.width; ++ix)
	{
		for (unsigned int iy = 0; iy < image.height; ++iy)
		{
			Color c = image.GetPixel(ix, iy);
			//solo lo dibujamos si no es transparente (nos lo dijo el quim esto)
			SetPixel(x + ix, y + iy, c);
		}
	}
}

void Image::DrawTriangleInterpolated(const sTriangleInfo& tri, FloatImage* zbuffer)
{
    // if zbuffer is null, we still raster but without depth testing
    bool useZ = (zbuffer != nullptr);

    const Vector3& p0 = tri.p0;
    const Vector3& p1 = tri.p1;
    const Vector3& p2 = tri.p2;

    // Bounding box
    int minX = (int)floorf(std::min(std::min(p0.x, p1.x), p2.x));
    int minY = (int)floorf(std::min(std::min(p0.y, p1.y), p2.y));
    int maxX = (int)ceilf(std::max(std::max(p0.x, p1.x), p2.x));
    int maxY = (int)ceilf(std::max(std::max(p0.y, p1.y), p2.y));

    minX = std::max(minX, 0);
    minY = std::max(minY, 0);
    maxX = std::min<int>(maxX, static_cast<int>(width) - 1);
    maxY = std::min<int>(maxY, static_cast<int>(height) - 1);

    // Precompute area (denominator)
    float denom = (p1.y - p2.y)*(p0.x - p2.x) + (p2.x - p1.x)*(p0.y - p2.y);
    if (fabs(denom) < 1e-6f) return; // degenerate

    Image* texture = tri.texture;

    for (int y = minY; y <= maxY; ++y) {
        for (int x = minX; x <= maxX; ++x) {
            // Compute barycentric weights (using pixel center)
            float px = (float)x + 0.5f;
            float py = (float)y + 0.5f;
            float w0 = ((p1.y - p2.y)*(px - p2.x) + (p2.x - p1.x)*(py - p2.y)) / denom;
            float w1 = ((p2.y - p0.y)*(px - p2.x) + (p0.x - p2.x)*(py - p2.y)) / denom;
            float w2 = 1.0f - w0 - w1;

            // If inside triangle
            if (w0 >= 0 && w1 >= 0 && w2 >= 0) {
                // Perspective-correct interpolation: interpolate 1/w and attributes multiplied by 1/w
                float rw_interp = w0 * tri.rw0 + w1 * tri.rw1 + w2 * tri.rw2;

                // Interpolate depth using perspective-correct method: z_over_w then divide
                float z_over_w = w0 * (p0.z * tri.rw0) + w1 * (p1.z * tri.rw1) + w2 * (p2.z * tri.rw2);
                float z = (rw_interp > 1e-9f) ? (z_over_w / rw_interp) : (w0 * p0.z + w1 * p1.z + w2 * p2.z);

                if (useZ) {
                    float currentZ = zbuffer->GetPixel((unsigned int)x, (unsigned int)y);
                    if (!(z < currentZ)) continue; // not closer
                }

                Color outColor;
                if (texture && rw_interp > 0.0f) {
                    // interpolate u/w and v/w
                    float u_over_w = w0 * (tri.uv0.x * tri.rw0) + w1 * (tri.uv1.x * tri.rw1) + w2 * (tri.uv2.x * tri.rw2);
                    float v_over_w = w0 * (tri.uv0.y * tri.rw0) + w1 * (tri.uv1.y * tri.rw1) + w2 * (tri.uv2.y * tri.rw2);
                    float u = u_over_w / rw_interp;
                    float v = v_over_w / rw_interp;

                    // clamp
                    u = clamp(u, 0.0f, 1.0f);
                    v = clamp(v, 0.0f, 1.0f);

                    // Fix orientation: flip both U and V so texture appears with correct upright features
                    // (some TGA files or UV conventions require a 180� rotation to match model UVs)
                    u = 1.0f - u;
                    v = 1.0f - v;

                    // map to texture space (float)
                    float u_tex = u * (texture->width - 1);
                    float v_tex = v * (texture->height - 1);
                    int x0t = (int)floorf(u_tex);
                    int y0t = (int)floorf(v_tex);
                    float fx = u_tex - x0t;
                    float fy = v_tex - y0t;

                    // clamp texel coords
                    int x1t = std::min(x0t + 1, (int)texture->width - 1);
                    int y1t = std::min(y0t + 1, (int)texture->height - 1);
                    x0t = std::max(0, x0t);
                    y0t = std::max(0, y0t);

                    Color c00 = texture->GetPixel(x0t, y0t);
                    Color c10 = texture->GetPixel(x1t, y0t);
                    Color c01 = texture->GetPixel(x0t, y1t);
                    Color c11 = texture->GetPixel(x1t, y1t);

                    // bilinear interpolation
                    float r0 = c00.r * (1.0f - fx) + c10.r * fx;
                    float g0 = c00.g * (1.0f - fx) + c10.g * fx;
                    float b0 = c00.b * (1.0f - fx) + c10.b * fx;

                    float r1 = c01.r * (1.0f - fx) + c11.r * fx;
                    float g1 = c01.g * (1.0f - fx) + c11.g * fx;
                    float b1 = c01.b * (1.0f - fx) + c11.b * fx;
						
                    float r = r0 * (1.0f - fy) + r1 * fy;
                    float g = g0 * (1.0f - fy) + g1 * fy;
                    float b = b0 * (1.0f - fy) + b1 * fy;

                    outColor = Color((unsigned char)r, (unsigned char)g, (unsigned char)b);
                } else {
                    // Interpolate color (no perspective correction needed for colors in this simple case)
                    float r = w0 * tri.c0.r + w1 * tri.c1.r + w2 * tri.c2.r;
                    float g = w0 * tri.c0.g + w1 * tri.c1.g + w2 * tri.c2.g;
                    float b = w0 * tri.c0.b + w1 * tri.c1.b + w2 * tri.c2.b;
                    outColor = Color((unsigned char)r, (unsigned char)g, (unsigned char)b);
                }

                // Write pixel and update zbuffer
                this->SetPixel((unsigned int)x, (unsigned int)y, outColor);
                if (useZ) zbuffer->SetPixel((unsigned int)x, (unsigned int)y, z);
            }
        }
    }
}
