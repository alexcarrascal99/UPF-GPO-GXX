#include "camera.h"

#include "main/includes.h"
#include <iostream>

Camera::Camera()
{
	view_matrix.SetIdentity();
	SetOrthographic(-1,1,1,-1,-1,1);
}

Vector3 Camera::GetLocalVector(const Vector3& v)
{
	Matrix44 iV = view_matrix;
	if (iV.Inverse() == false)
		std::cout << "Matrix Inverse error" << std::endl;
	Vector3 result = iV.RotateVector(v);
	return result;
}

Vector3 Camera::ProjectVector(Vector3 pos)
{
	Vector4 pos4 = Vector4(pos.x, pos.y, pos.z, 1.0);
	Vector4 result = viewprojection_matrix * pos4;
	if (type == ORTHOGRAPHIC)
		return result.GetVector3();
	else
		return result.GetVector3() / result.w;
}

void Camera::Rotate(float angle, const Vector3& axis)
{
	Matrix44 R;
	R.MakeRotationMatrix(angle, axis);
	Vector3 new_front = R * (center - eye);
	center = eye + new_front;
	UpdateViewMatrix();
}

void Camera::Move(Vector3 delta)
{
	Vector3 localDelta = GetLocalVector(delta);
	eye = eye - localDelta;
	center = center - localDelta;
	UpdateViewMatrix();
}

void Camera::SetOrthographic(float left, float right, float top, float bottom, float near_plane, float far_plane)
{
	type = ORTHOGRAPHIC;

	this->left = left;
	this->right = right;
	this->top = top;
	this->bottom = bottom;
	this->near_plane = near_plane;
	this->far_plane = far_plane;

	UpdateProjectionMatrix();
}

void Camera::SetPerspective(float fov, float aspect, float near_plane, float far_plane)
{
	type = PERSPECTIVE;

	this->fov = fov;
	this->aspect = aspect;
	this->near_plane = near_plane;
	this->far_plane = far_plane;

	UpdateProjectionMatrix();
}

void Camera::LookAt(const Vector3& eye, const Vector3& center, const Vector3& up)
{
	this->eye = eye;
	this->center = center;
	this->up = up;

	UpdateViewMatrix();
}

void Camera::UpdateViewMatrix()
{
	Vector3 forward = (center - eye).Normalize();
	Vector3 side = up.Cross(forward).Normalize();
	Vector3 cameraUp = forward.Cross(side).Normalize();

	view_matrix.SetIdentity();

	// Rotation
	view_matrix.M[0][0] = side.x;
	view_matrix.M[1][0] = side.y;
	view_matrix.M[2][0] = side.z;

	view_matrix.M[0][1] = cameraUp.x;
	view_matrix.M[1][1] = cameraUp.y;
	view_matrix.M[2][1] = cameraUp.z;

	view_matrix.M[0][2] = -forward.x;
	view_matrix.M[1][2] = -forward.y;
	view_matrix.M[2][2] = -forward.z;

	// Translation (dot products)
	view_matrix.M[3][0] = -side.Dot(eye);
	view_matrix.M[3][1] = -cameraUp.Dot(eye);
	view_matrix.M[3][2] = forward.Dot(eye);

	UpdateViewProjectionMatrix();
}


void Camera::UpdateProjectionMatrix()
{
	projection_matrix.SetIdentity();

	if (type == PERSPECTIVE)
	{
		float f = 1.0f / tanf(fov * 0.5f * DEG2RAD);

		projection_matrix.M[0][0] = f / aspect;
		projection_matrix.M[1][1] = f;

		projection_matrix.M[2][2] = (far_plane + near_plane) / (near_plane - far_plane);
		projection_matrix.M[2][3] = -1.0f;

		projection_matrix.M[3][2] = (2.0f * far_plane * near_plane) / (near_plane - far_plane);
		projection_matrix.M[3][3] = 0.0f;
	}
	else if (type == ORTHOGRAPHIC)
	{
		float rl = right - left;
		float tb = top - bottom;
		float fn = far_plane - near_plane;

		projection_matrix.M[0][0] = 2.0f / rl;
		projection_matrix.M[1][1] = 2.0f / tb;
		projection_matrix.M[2][2] = -2.0f / fn;

		projection_matrix.M[3][0] = -(right + left) / rl;
		projection_matrix.M[3][1] = -(top + bottom) / tb;
		projection_matrix.M[3][2] = -(far_plane + near_plane) / fn;
		projection_matrix.M[3][3] = 1.0f;

		projection_matrix.M[2][3] = 0.0f;
	}

	UpdateViewProjectionMatrix();
}


void Camera::UpdateViewProjectionMatrix()
{
	viewprojection_matrix = projection_matrix * view_matrix;
}

Matrix44 Camera::GetViewProjectionMatrix()
{
	UpdateViewMatrix();
	UpdateProjectionMatrix();

	return viewprojection_matrix;
}

// The following methods have been created for testing.
// Do not modify them.

void Camera::SetExampleViewMatrix()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye.x, eye.y, eye.z, center.x, center.y, center.z, up.x, up.y, up.z);
	glGetFloatv(GL_MODELVIEW_MATRIX, view_matrix.m );
}

void Camera::SetExampleProjectionMatrix()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (type == PERSPECTIVE)
		gluPerspective(fov, aspect, near_plane, far_plane);
	else
		glOrtho(left,right,bottom,top,near_plane,far_plane);

	glGetFloatv(GL_PROJECTION_MATRIX, projection_matrix.m );
	glMatrixMode(GL_MODELVIEW);
}
