/*  
	+ This class encapsulates the application, is in charge of creating the data, getting the user input, process the update and render.
*/

#pragma once

#include "main/includes.h"
#include "framework.h"
#include "image.h"
#include "button.h"
#include <vector>
#include "entity.h"

class Application
{
public:
	Vector2 startPos;
	bool isDrawing = false;
	Image drawingCanvas;
	int rectBorderWidth = 2;
	// Window

	SDL_Window* window = nullptr;
	int window_width;
	int window_height;

	float time;

	
	// Input
	const Uint8* keystate;
	int mouse_state; // Tells which buttons are pressed
	Vector2 mouse_position; // Last mouse position
	Vector2 mouse_delta; // Mouse movement in the last frame

	void OnKeyPressed(SDL_KeyboardEvent event);
	void OnMouseButtonDown(SDL_MouseButtonEvent event);
	void OnMouseButtonUp(SDL_MouseButtonEvent event);
	void OnMouseMove(SDL_MouseButtonEvent event);
	void OnWheel(SDL_MouseWheelEvent event);
	void OnFileChanged(const char* filename);

	// CPU Global framebuffer
	Image framebuffer;

	std::vector<Button> buttons;
	ButtonType selectedTool = BUTTON_PENCIL;
	Color selectedColor = Color::WHITE;

	// Animation / interactivity mode: false = Paint, true = Animation
	bool animationMode = false;

	// Fill mode: false = outline, true = filled (toggle with 'F')
	bool fillMode = false;

	// Scene camera and entities
	Camera camera;
	std::vector<Entity*> entities;

	// Camera interaction state
	bool cameraOrbiting = false; // left mouse (in animation mode)
	bool cameraPanning = false;  // right mouse
	int last_mouse_x = 0;
	int last_mouse_y = 0;


	// Interactivity: rendering modes and property selection
	enum CurrentProperty { PROP_NONE = 0, PROP_CAMERA_NEAR, PROP_CAMERA_FAR, PROP_CAMERA_FOV };
	CurrentProperty currentProperty = PROP_NONE;

	bool singleEntityMode = false; // true = draw single entity, false = draw multiple

	// Constructor and main methods
	Application(const char* caption, int width, int height);
	~Application();

	void Init( void );
	void Render( void );
	void Update( float dt );

	// Other methods to control the app
	void SetWindowSize(int width, int height) {
		glViewport( 0,0, width, height );
		this->window_width = width;
		this->window_height = height;
		this->framebuffer.Resize(width, height);
	}

	Vector2 GetWindowSize()
	{
		int w,h;
		SDL_GetWindowSize(window,&w,&h);
		return Vector2(float(w), float(h));
	}
};
